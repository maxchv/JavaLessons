package _06_concurrency.forkjoin.usingforkjoin;

import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class UsingFJ {
	private static final int SIZE = 10000;
	public static int processors;
	
	public static void main(String[] args) throws Exception {
		int[] data = generateData(SIZE);

//		alternative solution
//		Arrays.stream(data)
//				.parallel()
//				.forEach(item -> {
//					for (int j = 0; j < 5_000; ++j) {
//						Math.tan(item * 2);
//					}
//				});





		processors = 2;
		System.out.println("Processors: " + processors);
	
		System.out.println("Started");
		long start = System.currentTimeMillis();
		ForkJoinPool fjp = new ForkJoinPool(processors);
		fjp.invoke(new Task(data, 0, data.length));
		System.out.println(System.currentTimeMillis() - start);
	}
	
	private static int[] generateData(final int size) {
		final int[] result = new int[size];
		for (int i = 0; i < size; ++i) {
			result[i] = i;
		}
		return result;
	}
}

class Task extends RecursiveAction {
	
	private int[] _data;
	private int _from;
	private int _to;
	
	
	
	public Task(int[] data, int from, int to) {
//		System.out.printf("Created task. from = %d, to = %d%n", from, to);
		_data = data;
		_from = from;
		_to = to;
	}
	
	public void run() {
		for (int i = _from; i < _to; ++i) {
			doJobWithElement(_data[i]);
		}
		
	}

	private void doJobWithElement(int datum) {
		for (int j = 0; j < 5_000; ++j) {
            Math.tan(datum * 2);
        }
	}

	@Override
	protected void compute() {
//		System.out.println(_from + " " + _to);
		if (_to - _from < _data.length / UsingFJ.processors) {
			run();
		} else {
			invokeAll(new Task(_data, _from, (_to + _from) / 2 - 1),
					  new Task(_data, (_to + _from) / 2, _to));
		}
		
	}
	
}
